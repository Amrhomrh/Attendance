part of 'emp_dash_bloc.dart';

@immutable
abstract class EmpDashEvent extends Equatable{}

class EmpDashLoadingEvent extends EmpDashEvent{
  @override
  // TODO: implement props
  List<Object?> get props => [];

}
