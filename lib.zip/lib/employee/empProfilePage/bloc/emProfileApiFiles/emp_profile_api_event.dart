part of 'emp_profile_api_bloc.dart';

@immutable
abstract class EmpProfileApiEvent extends Equatable{}

class EmpProfileLoadingEvent extends EmpProfileApiEvent{
  @override
  // TODO: implement props
  List<Object?> get props => [];

}
