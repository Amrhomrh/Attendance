part of 'get_lat_long_bloc.dart';

@immutable
abstract class GetLatLongEvent {}

class FetchDataEvent extends GetLatLongEvent {}