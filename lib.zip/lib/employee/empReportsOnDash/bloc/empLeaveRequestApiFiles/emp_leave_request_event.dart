part of 'emp_leave_request_bloc.dart';

@immutable
abstract class EmpLeaveRequestEvent extends Equatable{}

class EmpLeaveRequestLoadingEvent extends EmpLeaveRequestEvent{
  @override
  // TODO: implement props
  List<Object?> get props => [];

}
