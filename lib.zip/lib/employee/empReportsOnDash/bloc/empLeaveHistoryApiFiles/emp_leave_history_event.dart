part of 'emp_leave_history_bloc.dart';

@immutable
abstract class EmpLeaveHistoryEvent extends Equatable{}

class EmpLeaveHistoryLoadingEvent extends EmpLeaveHistoryEvent{
  @override
  // TODO: implement props
  List<Object?> get props => [];

}