import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';


final AdminkbackgrounColorAppBar = Color(0xFFE26142);

final AdminkAppBarTextTheme = TextStyle(
  color: Color(0xFFFDF7F5),
  fontWeight: FontWeight.bold,
);

final kIconThemeData= IconThemeData(
color: Colors.white,
);