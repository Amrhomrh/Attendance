import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';


final EmpkbackgrounColorAppBar = Color(0xFFE26142);

final EmpkAppBarTextTheme = TextStyle(
  color: Color(0xFFFDF7F5),
  fontWeight: FontWeight.bold,
);
