
 const double defaultPadding=16.0;