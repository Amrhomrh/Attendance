part of 'admin_dash_bloc.dart';

@immutable
abstract class AdminDashboardkState {}

class AdminDashboardkInitial extends AdminDashboardkState {}

class NavigateToProfileState extends AdminDashboardkState{}
class NavigateToHomeState extends AdminDashboardkState{}
class NavigateToGeofenceState extends AdminDashboardkState{}
class NavigateToReportsState extends AdminDashboardkState{}
class NavigateToLogoutState extends AdminDashboardkState{}
class NavigateToLeavesState extends AdminDashboardkState{}
