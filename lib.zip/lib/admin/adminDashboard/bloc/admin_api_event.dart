part of 'admin_api_bloc.dart';

@immutable
abstract class AdminApiEvent extends Equatable{}
class AdminApiLoadingEvent extends AdminApiEvent {
  @override
  // TODO: implement props
  List<Object?> get props => [];
}

